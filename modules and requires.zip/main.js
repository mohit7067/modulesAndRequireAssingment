var a=50;
var b=2;




const add= require("./add")
const substract= require("./substract")
const multiply= require("./multiply")
const divide= require("./divide")


  console.log(add(a,b))
  console.log(substract(a,b))
  console.log(multiply(a,b))
  console.log(divide(a,b))