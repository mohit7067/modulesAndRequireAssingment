

function substract(a,b){
    return (a-b);
}

module.exports= substract;